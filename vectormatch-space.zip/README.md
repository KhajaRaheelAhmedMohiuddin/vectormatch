---
title: VectorMatch
emoji: 🧭
colorFrom: indigo
colorTo: blue
sdk: gradio
sdk_version: 6.32.0
app_file: app.py
python_version: "3.12"
short_description: Resume-to-job semantic search over 25K real job posts
license: mit
models:
  - KhajaHugging/bge-small-vectormatch
datasets:
  - lang-uk/recruitment-dataset-job-descriptions-english
tags: [semantic-search, hybrid-search, vector-database, faiss, rag, job-matching]
---

# 🧭 VectorMatch: live demo

Paste a resume and get ranked job matches from **25,000 real job posts**, plus the skills those jobs ask for that the
resume lacks. Retrieval uses a **fine-tuned embedding model** ([KhajaHugging/bge-small-vectormatch](https://huggingface.co/KhajaHugging/bge-small-vectormatch)), BM25 and
weighted rank fusion, on a choice of five vector databases.

Code, benchmarks and methodology: **https://github.com/KhajaRaheelAhmedMohiuddin/vectormatch**
